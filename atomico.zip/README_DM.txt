This is a freeware typeface.
You can use it on your personal and commercial works for free. 

If you like it and want to retribute, you can:
- Credit the typeface name on your work.
- Send me a sample of the work you did using my typeface
- Mail me some print material you did using my typeface
- Donate using PayPal on dafont site.

PLEASE:
- Ask me to redistribute this font. I will be happy, i just wanna know.
- Don't sell this font, it�s free!
- Let me know if you modify it.

CONTACT:

Daniel Maciel 
Rua Deusdalma 121
Nova Gameleira
Belo Horizonte - MG
Brazil 30510-390

MSN and EMAIL: mensagemprodaniel@gmail.com

